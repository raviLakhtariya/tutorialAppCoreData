-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 06, 2018 at 07:42 PM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user_post_demo`
--
CREATE DATABASE IF NOT EXISTS `user_post_demo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `user_post_demo`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

DROP TABLE IF EXISTS `tbl_company`;
CREATE TABLE IF NOT EXISTS `tbl_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(55) NOT NULL,
  `company_email` varchar(55) NOT NULL,
  `company_password` varchar(110) NOT NULL,
  `company_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`id`, `company_name`, `company_email`, `company_password`, `company_status`) VALUES
(2, 'Sinon', 'sinon@gmail.com', 'cfe609497d9f6e9a4dc30e1ffe1331ec', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_post`
--

DROP TABLE IF EXISTS `tbl_company_post`;
CREATE TABLE IF NOT EXISTS `tbl_company_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `post_name` varchar(110) NOT NULL,
  `post_description` varchar(220) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_company_post`
--

INSERT INTO `tbl_company_post` (`id`, `company_id`, `post_name`, `post_description`) VALUES
(1, 2, 'Hello World', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(55) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(110) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user_name`, `email`, `password`, `mobile_no`, `gender`, `status`) VALUES
(1, 'admin', 'admin@gmail.com', 'cfe609497d9f6e9a4dc30e1ffe1331ec', '7894561232', 'Male', 1),
(2, 'demo', 'demo@gmail.com', 'cfe609497d9f6e9a4dc30e1ffe1331ec', '9876543214', 'Male', 1),
(8, 'admin1', 'demo1@gmail.com', 'cfe609497d9f6e9a4dc30e1ffe1331ec', '5541237896', 'Male', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_post`
--

DROP TABLE IF EXISTS `tbl_user_post`;
CREATE TABLE IF NOT EXISTS `tbl_user_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_name` varchar(110) NOT NULL,
  `post_description` varchar(220) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_user_post`
--

INSERT INTO `tbl_user_post` (`id`, `user_id`, `post_name`, `post_description`) VALUES
(8, 1, 'file 123', 'abc');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
